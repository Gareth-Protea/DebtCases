import type { Request, Response } from "express";
import { storage } from "../../storage";

// ── Debt Manager Controllers ──────────────────────────────────
// Add controller functions for debt features here.
// Each function handles the business logic for one route.

export async function getDebtRecords(req: Request, res: Response) {
  try {
    const data = await storage.getDebtRecords();
    res.json(data);
  } catch (err: any) {
    res.status(500).json({ message: err.message });
  }
}

// Add more debt controller functions below
